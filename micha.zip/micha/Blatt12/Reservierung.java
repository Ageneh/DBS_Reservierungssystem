import java.sql.*; /* Die Schnittstellendefinition */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;


public class Reservierung {

    public static void main(String[] args) throws FileNotFoundException {
        PrintWriter pw = new PrintWriter(new File("reservierung_statistik.csv"));
        StringBuilder sb = new StringBuilder();

        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Driver did not load - aborting");
            System.exit(-1);
        }
        Connection con = null;
        try {
            String url =
                    "jdbc:postgresql://db.intern.mi.hs-rm.de:5432/mheid001";
            con = DriverManager.getConnection(url, "mheid001", "");
        } catch (SQLException e) {
            System.out.println("Couldn't connect - aborting");
            System.exit(-1);
        }
        Statement stmt = null;
        try {
            stmt = con.createStatement();

        } catch (SQLException e) {
            System.out.println("Statement creation failed - aborting");
            System.exit(-1);
        }
        try {
            String query = "SELECT COUNT(R.vorstellungid), V.titel, V.saalname  from reservierung R, vorstellung V where R.vorstellungid = V.vorstellungid GROUP BY V.titel, V.saalname, R.vorstellungid;\n";
            ResultSet rs = stmt.executeQuery(query);
            System.out.println("Reservierungen: ");

            sb.append("Anzahl");
            sb.append(",");
            sb.append("Titel");
            sb.append(",");
            sb.append("Saalname");
            sb.append('\n');

            while (rs.next()) {
                String line1 = rs.getString("count");
                sb.append(line1);
                sb.append(",");
                String line2 = rs.getString("titel");
                sb.append(line2);
                sb.append(",");
                String line3 = rs.getString("saalname");
                sb.append(line3);
                sb.append('\n');
                System.out.println(line1 + " " + line2 + " " + line3);
            }
            pw.write(sb.toString());
            pw.close();
        } catch (SQLException e) {
            System.out.println("Querying failed - aborting");
            System.exit(-1);
        }
    }

}
