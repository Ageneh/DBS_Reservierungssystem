DROP TABLE reservierung;
DROP TABLE vorstellung;
DROP TABLE kategorie;
DROP TABLE platz;
DROP TABLE saal;
DROP TABLE regBenutzer;

DROP TABLE speisen;
DROP TABLE film;
DROP TABLE plz;

CREATE TABLE speisen(
	    produktID VARCHAR(80) PRIMARY KEY,
	    produktBeschreibung VARCHAR(255)
);

CREATE TABLE plz(
	    plz NUMERIC(5,0) PRIMARY KEY,
	    ort VARCHAR(80)
);

CREATE TABLE saal(
	    saalName VARCHAR(20),
	    PRIMARY KEY (saalName)
);

CREATE TABLE film(
	    titel VARCHAR(100) PRIMARY KEY,
	    hauptdarsteller VARCHAR(80),
	    genre VARCHAR(80),
	    spieldauer TIME(2)
);
----mit references
-- + plz
CREATE TABLE regBenutzer(
    nutzerID CHAR(12) UNIQUE,
    email VARCHAR(80) UNIQUE,
    vorname VARCHAR(80) NOT NULL,
    nachname VARCHAR(80) NOT NULL,
    strasse VARCHAR(80) NOT NULL,
    hausNr SMALLINT,
    plz NUMERIC(5,0),

    PRIMARY KEY (nutzerID, email),

    FOREIGN KEY (plz) REFERENCES plz(plz)
);
-- + saal
CREATE TABLE platz(
	    reihe NUMERIC(2,0) NOT NULL,
	    sitz NUMERIC(2,0) NOT NULL,
	    saalName VARCHAR(20),

			UNIQUE(saalName, reihe, sitz),

	    PRIMARY KEY (saalName, reihe, sitz),
	    FOREIGN KEY (saalName) REFERENCES saal(saalName)
);

-- + platz -- + saal
CREATE TABLE kategorie(
	    name VARCHAR(80) PRIMARY KEY,
	    preis FLOAT(2),
	    saalName VARCHAR(20),
	    reihe NUMERIC(2,0),
	    sitz NUMERIC(2,0),

	    FOREIGN KEY (saalName, reihe, sitz) REFERENCES platz(saalName, reihe, sitz)
);

-- + film, saal
CREATE TABLE vorstellung(
	    vorstellungID CHAR(6),
	    datum_zeit TIMESTAMP NOT NULL,
			titel VARCHAR(100),
	    ---PRIMARY KEY (datum_zeit, vorstellungID),
	    saalName VARCHAR(20),

	    FOREIGN KEY (titel) REFERENCES film(titel),
	    FOREIGN KEY (saalName) REFERENCES saal(saalName),

	    PRIMARY KEY(titel, datum_zeit, saalName)
);

-- + regBenutzer, vorstellung
CREATE TABLE reservierung(
    vorstellungID CHAR(6),
    nutzerID CHAR(12),
    FOREIGN KEY (nutzerID) REFERENCES regBenutzer(nutzerID),
		-- datum_zeit TIMESTAMP NOT NULL,
		-- titel VARCHAR(100),
		-- saalName VARCHAR(20),
					UNIQUE(vorstellungID, reihe, sitz),
		PRIMARY KEY (nutzerID, vorstellungID, sitz, reihe),
		saalName VARCHAR(20),
    reihe NUMERIC(2,0),
    sitz NUMERIC(2,0),
    FOREIGN KEY (saalName,reihe, sitz) REFERENCES platz(saalName,reihe, sitz),

    produktID VARCHAR(80),
		rabatt FLOAT(2) CHECK(rabatt >= 0 AND rabatt <= 50),
    FOREIGN KEY (produktID) REFERENCES speisen(produktID)
);
