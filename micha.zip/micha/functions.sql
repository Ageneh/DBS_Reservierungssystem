drop function reserviere(CHAR, CHAR, NUMERIC, NUMERIC);
CREATE OR REPLACE FUNCTION reserviere(vID CHAR, nID CHAR, reihe NUMERIC, sitz NUMERIC)
RETURNS TEXT AS $$
  DECLARE
    ret_str VARCHAR(80) = $1 || delim || $2 || delim || $3 || delim || $4;
  BEGIN
  IF reihe IS NOT NULL AND sitz IS NOT NULL THEN
    INSERT INTO reservierung(vorstellungID, nutzerID, reihe, sitz) VALUES($1, $2, $3, $4);
  END IF;
  RETURN ret_str;
  END
$$
LANGUAGE 'plpgsql';

SELECT * FROM reservierung;

---------reserviere(CHAR, CHAR, NUMERIC, NUMERIC)

SELECT * FROM regBenutzer;
SELECT reserviere('RudiRud', 'VSI005', 2,1);
SELECT * FROM regBenutzer;
SELECT reserviere('SteLos', 'VSI003', 5,6);
SELECT * FROM reservierung;
SELECT reserviere('Simsala', 'VSI002', 5,6);
SELECT * FROM reservierung;
