drop function reserviere(CHAR, CHAR, NUMERIC, NUMERIC, CHAR);
CREATE OR REPLACE FUNCTION reserviere(vID CHAR, nID CHAR, reihe NUMERIC, sitz NUMERIC, saal CHAR)
RETURNS TEXT AS $$
  DECLARE
    vID CHAR(6) = $1;
    nID CHAR(12) = $2;
    reihe NUMERIC(2,0) = $3;
    sitz NUMERIC(2,0) = $4;
    saal VARCHAR(20) = $5;
  BEGIN
  IF reihe IS NOT NULL AND sitz IS NOT NULL THEN
    INSERT INTO reservierung(vorstellungID, nutzerID, reihe, sitz, saalName) VALUES(vID,nId,reihe,sitz,saal);
  END IF;
  RETURN nID;
  END
$$
LANGUAGE 'plpgsql';

SELECT * FROM reservierung;

---------reserviere(CHAR, CHAR, NUMERIC, NUMERIC)

SELECT * FROM regBenutzer;
SELECT reserviere('VSB001','RudiRud',  2,1,'Capitol');

SELECT * FROM reservierung;

-- Storno
DROP FUNCTION storno(CHAR,CHAR);
CREATE OR REPLACE FUNCTION storno(nID CHAR, vID CHAR)
RETURNS VOID AS $$
  DECLARE
    nID CHAR(12) = $1;
    vID CHAR(6) = $2;
  BEGIN
  DELETE FROM reservierung WHERE nutzerID = nID AND vorstellungID = vID;
  END
$$
LANGUAGE 'plpgsql';

select storno('RudiRud','VSW001');
SELECT * FROM reservierung;
