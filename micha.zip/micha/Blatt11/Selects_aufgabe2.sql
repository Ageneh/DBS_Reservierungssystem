
-- Übersicht auslastung Säle
select vorstellungID, count(*) from reservierung group by vorstellungID order by vorstellungID;

--Übersicht statistik zur beliebtheit einzelner filme
SELECT COUNT(R.vorstellungid), V.titel, V.saalname  from reservierung R, vorstellung V where R.vorstellungid = V.vorstellungid GROUP BY V.titel, V.saalname, R.vorstellungid;

-- filmephelung
SELECT COUNT(R.vorstellungid) as Empfehlenswert, V.titel from reservierung R, vorstellung V where R.vorstellungid = V.vorstellungid GROUP BY V.titel, R.vorstellungid ORDER BY empfehlenswert DESC;
